# This program calculates and displays monthly and annual expenses from user-inputted data.
# 9 June 2024
# CSC121 M2pro_main_debugging
# Ruben Guillen

"""
Pseudocode:
1. Start
2. Import the exFunctions module to use predefined functions for expense calculations.
3. Define the main function to control the flow of the program:
   a. Prompt the user to enter monthly expense amounts for housing, car insurance, gas, electricity, water, and groceries.
   b. Ask the user if there are any additional expenses.
      i. Continuously prompt for a response until a valid answer ('y' or 'n') is given:
         - If the user provides an invalid response, display an error message and ask again.
      ii. If the user responds 'y', prompt for the amount of the additional expenses and include this in the total calculation.
      iii. If the user responds 'n', set additional expenses to 0.
   c. Call the showExpenses function from the exFunctions module, passing all the collected expense amounts to calculate the total monthly and annual expenses.
   d. Call the display function from the exFunctions module to output the calculated total monthly and annual expenses.
4. Execute the main function if the script is run as the main program to ensure that the script performs its intended function when directly executed.
5. End
"""

import exFunctions as ef  # Importing custom functions for expense calculations

def main():
    # Get user inputs for various expenses
    housing = float(input('Enter the monthly rent or mortgage amount: '))
    insurance = float(input('Enter the monthly amount spent on car insurance(if applicable): '))
    gas = float(input('Enter the monthly amount spent on gas or transportation: '))
    electricity = float(input('Enter amount spent on electricity: '))
    water = float(input('Enter water bill amount: '))
    groceries = float(input('Enter the monthly amount spent on Groceries: '))

    # Check for additional expenses
    more = input('Are there more expenses you would like to add? (y/n): ').lower()
    while more not in ['y', 'n']:
            print("Invalid input. Please enter 'y' for yes or 'n' for no.")
            more = input('Are there more expenses you would like to add? (y/n): ').lower()

    if more == 'y':  # Ensure case insensitivity with lower()
        extra = float(input('Enter the monthly amount spent Extra expenses: '))
    else:
        extra = 0

    # Calculate and retrieve total monthly and annual expenses
    totalMonth, totalYear = ef.showExpenses(housing, insurance, gas, electricity, water, groceries, extra)

    # Display the calculated expenses
    ef.display(totalMonth, totalYear)

if __name__ == '__main__':
    main()
