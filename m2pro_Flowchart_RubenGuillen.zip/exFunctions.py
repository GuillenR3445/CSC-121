# This program defines functions to calculate and display total monthly and annual expenses.
# 9 June 2024
# CSC121 M2pro_main_debugging
# Ruben Guillen

"""
Pseudocode:
1. Define showExpenses function to calculate total monthly and annual expenses:
   - Accepts expenses for housing, gas, insurance, electricity, water, groceries, and extra.
   - Calculates the total monthly expense by summing all categories.
   - Calculates the total annual expense by multiplying the monthly total by 12.
   - Returns the monthly and annual totals.
2. Define display function to format and print the calculated expenses:
   - Formats and prints the total monthly expense.
   - Formats and prints the total annual expense.   
"""

def showExpenses(housing, gas, insurance, elec, water, grocery, extra):
    """
    Calculates total monthly and annual expenses from individual components.
    Returns: Tuple (totalMonth, totalYear)
    """
    totalMonth = housing + insurance + gas + elec + water + grocery + extra
    totalYear = totalMonth * 12
    return totalMonth, totalYear

def display(totalMonth, totalYear):
    """
    Displays the total monthly and yearly expenses formatted to two decimal places.
    """
    print(f'{"Total monthly expense:":<25}${totalMonth:.2f}')
    print(f'{"Total annual expense:":<25}${totalYear:.2f}')